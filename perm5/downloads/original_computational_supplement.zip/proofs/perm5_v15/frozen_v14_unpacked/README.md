# `perm_5` v14 ordinary-file mirror

This directory exposes the load-bearing v14 `perm_5` proof text, all 28 active
finite producers, their frozen JSON certificates, and the package manifest as
ordinary repository files. Each copied byte comes from the immutable reviewer
ZIP with SHA-256
`CE8F639C532B754B4E0A8EEC959D97E461426C9F9402B923D6A13056F46DFF33`.

The v15 full replay verifies every mirrored file against `PACKAGE_MANIFEST.json`
before and after executing all 28 producers from this directory. This mirror
improves reviewability; it does not replace or mutate the frozen ZIP.

The Chinese proof source is accompanied by the English review ledger and the
single-page theorem evidence index in `docs/`.
